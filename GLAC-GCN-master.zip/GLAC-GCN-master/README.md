# GLAC-GCN
Global and Local Topology-Aware Contrastive Graph Clustering Network

# Paper
https:

# Dataset
Due to the limitation of file size, the complete data can be found in Baidu Netdisk:

graph: 链接:https://pan.baidu.com/s/1MEWr1KyrtBQndVNy8_y2Lw  密码:opc1

data: 链接:https://pan.baidu.com/s/1kqoWlElbWazJyrTdv1sHNg  密码:1gd4

# run
```
pretrain_optimize_A_graph.py
GLAC_GCN.py
```

# Reference
If you find our approach useful in your research, please consider citing:
```

```
